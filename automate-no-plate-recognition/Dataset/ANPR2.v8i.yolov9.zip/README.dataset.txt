# ANPR2 > 2023-08-08 10:49am
https://universe.roboflow.com/arvind-kumar-wjygd/anpr2-syxl7

Provided by a Roboflow user
License: CC BY 4.0

